var isButtonTouched = false;
var cloverCollisionSize = 0.3;

var isFirstPointLeft = false;

var DELTA_COEFF = 0.09;

var DELTA_ARRAY = [16.,16.,16.,16.,16.];
var DELTA_TIME = 16.;

var testFinished = false;
var isDown = false;
var isClicked = false;

var posX = 0.01;
var posY = 0.01;

var mov1X = -0.6;
var mov1Y = -0.6;

var mov2X = 0.8;

var button1 = {x: 0.67,y: 0.9};
var button2 = {x: -0.67,y: 0.9};

var sliderData = {
    posX: 0,
    posY: -0.4,
    scaleX: 0.8,
    buttonValue: 1.,
};

var currPos = [0.8,sliderData.posY+0.13];

var buttonScreenPos = {
    x: calcScreenPos(),
    y: sliderData.posY
};

let EyesMorph = AddMorphing("EyeSizeMinus", 0);



function testSlider() {
    if (!testFinished && !isDown && (sliderData.buttonValue <= 1.)) {
        sliderData.buttonValue -= 0.0075 * DELTA_TIME * DELTA_COEFF;
        if (sliderData.buttonValue <= 0.01) isDown = true;
        updateSliderPos();
        Api.print(sliderData.buttonValue);
        timeOut(10, function(){
            testSlider();
        });
    } else if (!testFinished) {
        sliderData.buttonValue += 0.0075 * DELTA_TIME * DELTA_COEFF;
        updateSliderPos();
        timeOut(10, function(){
            testSlider();
        });
        if (sliderData.buttonValue >= 0.5) {
            sliderData.buttonValue = 0.5;
            updateSliderPos();
            Api.meshfxMsg("del", 3);
            testFinished = true;
            return;
        }
    }
}

function Effect() {
    var self = this;

    this.upd = onLibUpdate();

    this.init = function() {
        Api.meshfxMsg("spawn", 0, 0, "!glfx_FACE");

        // Api.meshfxMsg("spawn", 1, 0, "quad_slider.bsm2");
        // Api.meshfxMsg("tex", 1, 0, "Slider.png");

        // Api.meshfxMsg("spawn", 2, 0, "quad_button.bsm2");
        // Api.meshfxMsg("tex", 2, 0, "Button.png");
        // Api.meshfxMsg("tex", 2, 1, "Slider.png");

        // Api.meshfxMsg("spawn", 3, 0, "quad_0.bsm2");
        // Api.meshfxMsg("tex", 3, 0, "hand_1.png");

        // testSlider();
        EyesMorph.setWeight(0)



        // Api.meshfxMsg("shaderVec4", 0, 0, sliderData.posX + ' ' + sliderData.posY + ' ' + sliderData.scaleX + ' ' + sliderData.buttonValue);

        Api.showRecordButton();
    };

    this.delHint = function() {
        Api.meshfxMsg("del", 3);
    }

    this.restart = function() {
        Api.meshfxReset();
        self.init();
    };

    this.faceActions = [moveObject,this.upd];
    this.noFaceActions = [moveObject,this.upd];

    this.videoRecordStartActions = [this.delHint];
    this.videoRecordFinishActions = [];
    this.videoRecordDiscardActions = [this.restart];
}

function onTakePhotoStart(){
    Api.meshfxMsg("del", 1);
    Api.meshfxMsg("del", 2);
    Api.meshfxMsg("del", 3);
};

configure(new Effect());

function AddMorphing(name, i){
	const assetManager = bnb.scene.getAssetManager();
	const morphMesh = assetManager.createStaticMesh("scene_morphing_mesh_"+name);
	assetManager.uploadMeshData(morphMesh, "meshes/"+name+".bsm2"); // здесь указываем меш морфинга
	
	const initLayer = bnb.Layer.create(name+"_morph_layer");
	// const initEntity = bnb.scene.createEntity(name+"_morph_entity");
    let initEntity = bnb.scene.getRoot().findChildByName("face_tracker0").findChildByName("morph")

    if(i === 0){
	    initEntity = bnb.scene.getRoot().findChildByName("face_tracker0").findChildByName("morph2")
    }

	const morphing = assetManager.createMorph(name, bnb.MorphingType.MESH)
	morphing.setWarpMesh(morphMesh)
	
	const FaceMorphing = bnb.FaceMorphing.create();
	FaceMorphing.setMorphing(morphing)
	FaceMorphing.setVisible(true)
	FaceMorphing.setWeight(0.);
	
	initEntity.addIntoLayer(initLayer);
	initEntity.addComponent(FaceMorphing.asComponent());
	
	// bnb.scene.getRoot().findChildByName("face_tracker0").addChild(initEntity);
	
	// const initRT = bnb.scene.getRenderList().getTaskTarget(2); // здесь нужно выбрать номер рендер таргета. Проще подбором, пока картинка не начнет морфится. Иначе будет черный экран. Значение обычно лежит где-то после 30 для эффекта студии
	
	// bnb.scene.getRenderList().addTask(initLayer, initRT);
	bnb.log("ADDED "+ name)
	return FaceMorphing
}

function calcScreenPos(){
    return -sliderData.scaleX + sliderData.scaleX * sliderData.buttonValue * 2.;
}

function updateSliderPos(){
    buttonScreenPos.x = calcScreenPos();
    EyesMorph.setWeight(-sliderData.buttonValue * 4 + 2)
    Api.meshfxMsg("shaderVec4", 0, 0, sliderData.posX + ' ' + sliderData.posY + ' ' + sliderData.scaleX + ' ' + sliderData.buttonValue);
}

function collisionCheck(pointX, pointY, targetX, targetY, size) {
	if (pointX > targetX - size) {
		if (pointX < targetX + size) {
			if (pointY > targetY - size) {
				if (pointY < targetY + size) return true;
			}
		}
	}
	return false;
}

function onTouchesBegan(touches) {
    // if (collisionCheck(touches[0].x, touches[0].y, buttonScreenPos.x, buttonScreenPos.y, cloverCollisionSize)) {
    //     isButtonTouched = true;
    //     return;
    // }
}

function onTouchesMoved(touches)
{
    // if (isButtonTouched) {
    //     sliderData.buttonValue = (touches[0].x + sliderData.scaleX)/ (2 * sliderData.scaleX);
    //     if(sliderData.buttonValue < 0) {
    //         sliderData.buttonValue = 0;
    //     } else if (sliderData.buttonValue > 1){
    //         sliderData.buttonValue = 1;
    //     }
    //     updateSliderPos();
    // }
}

function onTouchesEnded(touches) {
    // isButtonTouched = false;
}

function timeOut(delay, callback) {
    var timer = new Date().getTime();

    effect.faceActions.push(removeAfterTimeOut);
    effect.noFaceActions.push(removeAfterTimeOut);

    function removeAfterTimeOut() {
        var now = new Date().getTime();

        if (now >= timer + delay) {
            var idx = effect.faceActions.indexOf(removeAfterTimeOut);
            effect.faceActions.splice(idx, 1);
            idx = effect.noFaceActions.indexOf(removeAfterTimeOut);
            effect.noFaceActions.splice(idx, 1);
            callback();
        }
    }
}

function moveObject(){
    var stepCoeffY = mov1Y/mov1X;
    if (currPos[0] > mov1X && !isFirstPointLeft) {
        currPos[0] -= 0.011 * DELTA_TIME * DELTA_COEFF;
    } else if (!isFirstPointLeft){
        isFirstPointLeft = true;
        isClicked = true;

        currPos[0] = mov1X;
    }
    if (isFirstPointLeft == true && isClicked){
        currPos[0] += 0.011 * DELTA_TIME * DELTA_COEFF;
        if(Math.abs(currPos[0]) >= Math.abs(mov2X)) {
            isClicked = false;
            currPos[0] = mov2X;

            timeOut(500, function(){
                var idx = effect.faceActions.indexOf(moveObject);
                effect.faceActions.splice(idx, 1);
                idx = effect.noFaceActions.indexOf(moveObject);
                effect.noFaceActions.splice(idx, 1);
                Api.meshfxMsg("del", 3);
            });
        }
    }
    Api.meshfxMsg("shaderVec4", 0, 1, currPos[0] + " " + currPos[1] + " " + "0 0"); 
};

function findAvg(array) {
    var result = 0;
    array.forEach(function(element){
        result += element;
    });

    return result/array.length;
}

function onLibUpdate() {
    var lastTime = new Date().getTime();
    return function () {
        var now = new Date().getTime();
        var newDelta = now - lastTime;
        lastTime = now;
        DELTA_ARRAY.push(newDelta);
        DELTA_ARRAY.shift();
        
        DELTA_TIME = findAvg(DELTA_ARRAY);
    };
};

function onDataUpdate(slider) {
    EyesMorph.setWeight(-slider * 3 + 1.5)
}