bnb.scene.enableRecognizerFeature(bnb.FeatureID.RING);
