'use strict';

require('bnb_js/global');
require('./modules/scene/index.js');
const modules_skin_index = require('./modules/skin/index.js');
const modules_index = require('./modules/index.js');
const modules_makeup_index = require('./modules/makeup/index.js');


function _interopDefaultLegacy (e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }

const Skin = new modules_skin_index.Skin();
const Makeup = new modules_makeup_index.Makeup();

const setState = modules_index.createSetState({
    Skin,
    Makeup
});

const m = /*#__PURE__*/Object.freeze({
    __proto__: null,
    Skin: Skin,
    Makeup: Makeup,
    setState: setState
});

exports.m = m;
