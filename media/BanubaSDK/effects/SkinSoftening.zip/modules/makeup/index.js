'use strict';

require('bnb_js/global');
const modules_scene_index = require('../scene/index.js');

const Soft = "modules/makeup/soft_low.png";

const vertexShader = "modules/makeup/makeup.vert";

const fragmentShader = "modules/makeup/makeup.frag";

class Makeup {
    constructor() {
        Object.defineProperty(this, "_makeup", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: new modules_scene_index.Mesh(new modules_scene_index.FaceGeometry(), new modules_scene_index.ShaderMaterial({
                vertexShader,
                fragmentShader,
                uniforms: {
                    tex_soft: new modules_scene_index.Image(Soft),
                    glfx_BACKGROUND: new modules_scene_index.Scene(),
                    var_soft_intensity: new modules_scene_index.Vector4(0, 0, 0, 0),
                },
            }))
        });
        this._makeup.visible(false);
        const onChange = () => {
            const isEyesCorrectionNeeded = [
                this._makeup.material.uniforms.var_soft_intensity.value(),
            ].some(([, , , a]) => a > 0);
            if (isEyesCorrectionNeeded)
                modules_scene_index.enable("EYES_CORRECTION", this);
            else
                modules_scene_index.disable("EYES_CORRECTION", this);
        };
        this._makeup.material.uniforms.var_soft_intensity.subscribe(onChange);
        modules_scene_index.add(this._makeup);
    }

    soft(value) {
        this._makeup.visible(true);
        this._makeup.material.uniforms.var_soft_intensity.value(value);
    }

    clear() {
        this.soft("0 0 0 0");
        this._makeup.visible(false);
    }
}
function isUrl(str) {
    return str === "" || /^\S+\.\w+$/.test(str);
}

exports.Makeup = Makeup;
