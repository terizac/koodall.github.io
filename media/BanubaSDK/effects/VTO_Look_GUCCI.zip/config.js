const { setState, setMode } = require("./js/index.js")

Object.assign(globalThis, { setState, setMode })

/**
 * Usage example
 *
 * @example
 * ```js
 *  config.js call example
 *
 * setState({
 *    "foundation": {
 *      "color": "0.82 0.49 0.39",  // "r g b" color
 *      "finish": "matte",
 *      "coverage": "hi"            // "hi" "mid" or "low"
 *    },
 *    "blush": {
 *      "color": "0.81 0.27 0.43",
 *      "finish": "matte",
 *      "coverage": 0.7,            // custom number is allowed too
 *    },
 *    "lipstick": {
 *      "color": "1.0 0.70 0.49",
 *      "finish": {                  // custom dictionary is allowed too
 *        "A": 1,
 *        "C": 1,
 *        "K": 0.5,
 *        "R": 1,
 *        "P": -1,
 *      },
 *    },
 *    // etc
 * })
 * ```
 *
 * @example
 * ```py
 * // python sdk bindings call example":
 *
 * settings = {
 *    "foundation": {
 *      "color": "0.82 0.49 0.39",  // "r g b" color
 *      "finish": "matte",
 *      "coverage": "hi"            // "hi" "mid" or "low"
 *    },
 *    "blush"": {
 *      "color": "0.81 0.27 0.43",
 *      "finish": "matte",
 *      "coverage": 0.7,            // custom number is allowed too
 *    },
 *    "lipstick": {
 *      "color": "1.0 0.70 0.49",
 *      "finish": {                  // custom dictionary is allowed too
 *        "A": 1,
 *        "C": 1,
 *        "K": 0.5,
 *        "R": 1,
 *        "P": -1,
 *      },
 *    },
 *    // etc
 * }
 *
 * state = json.dumps(settings)
 *
 * effect.eval_js(f"setState({state})")
 * ```
 */

// empty state by default
setState({})
// "speed" mode by default, available modes: "speed", "quality"
setMode("speed")

/** You can set a default state here */
// setState(
//   {
//     "blush": {
//       "color": "0.88 0.65 0.75",
//       "finish": "shimmer",
//       "coverage": "mid"
//     },
//     "concealer": {
//       "color": "0.94 0.73 0.66",
//       "finish": "natural",
//       "coverage": 0
//     },
//     "contour": {
//       "color": "1 0 0",
//       "finish": "normal",
//       "coverage": "mid",
//     },
//     "eyebrows": {
//       "color": "0.39 0.26 0.27",
//       "finish": "matte",
//       "coverage": "mid"
//     },
//     "eyeliner": {
//       "color": "0.0 0.0 0.0",
//       "finish": "matte_liquid",
//       "coverage": "hi"
//     },
//     "eyeshadow0": {
//       "color": "0.21 0.42 0.32",
//       "finish": "matte",
//       "coverage": "hi"
//     },
//     "eyeshadow1": {
//       "color": "0.3 0.58 0.47",
//       "finish": "shimmer",
//       "coverage": "hi"
//     },
//     "eyeshadow2": {
//       "color": "1.00 0.91 0.27",
//       "finish": "metallic",
//       "coverage": "hi"
//     },
//     "foundation": {
//       "color": "0.95 0.70 0.54",
//       "finish": "natural",
//       "coverage": "mid"
//     },
//     "highlighter": {
//       "color": "0.9 0.80 0.83",
//       "finish": "shimmer",
//       "coverage": 0
//     },
//     "lipstick": {
//       "color": "0.88 0.47 0.61",
//       "finish": "shimmer",
//       "coverage": "hi"
//     },
//     "lipsliner": {
//       "color": "0.99 0.0 0.0",
//       "finish": "shimmer",
//       "coverage": "hi"
//     },
//     "eyelashes": {
//       "color": "0 0 0",
//       "finish": "volume",
//       "coverage": "hi"
//     }
//   }
// )

// setMode("quality")

// Temporary utility helper
const morph = bnb.scene
  .getRoot()
  .findChildByName("lips_morphing")
  .getComponent(bnb.ComponentType.FACE_MORPHING)
  .asFaceMorphing()

const setLipsVolume = (number) => {
  morph.setWeight(number)
  morph.setVisible(number !== 0)
}

// r1 controls liner width, r2 controls softness
const setLipsLinerR1R2 = (r1, r2) => {
  bnb.scene.getAssetManager().findMaterial("shaders/lipsliner/liner2").findParameter("lipsliner_r1_r2").setVector4(new bnb.Vec4(r1, r2, 0, 0))
}

// setState(
//   {
//     "lipsliner": {
//       "color": "0.99 0.0 0.0",
//       "finish": "shimmer",
//       "coverage": "hi"
//     }
//   }
// )

// setLipsLinerR1R2(5, 5)


/** You can set a default state here */
 setState(
   {
       "foundation": {
       "color": "0.894 0.682 0.505",
       "finish": "natural",
       "coverage": "lo"
     },
      "eyeliner": {
       "color": "0.635 0.776 0.898",
       "finish": "cream",
       "coverage": "hi"
     },
       "eyebrows": {
       "color": "0.396 0.384 0.388",
       "finish": "matte",
       "coverage": "mid"
     },
       "eyeshadow": {
       "color": "0.643 0.525 0.494",
       "finish": "shimmer",
       "coverage": "hi"
     },
       "lipstick": {
       "color": "1.0 0.439 0.486",
       "finish": "balm",
       "coverage": "hi"
     }
   }
 )