Background = require('bnb_js/background');

Background.texture("images/Dawn_of_nature.jpg");
Background.contentMode("fill")