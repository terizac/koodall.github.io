//bnb.scene.enableRecognizerFeature(bnb.FeatureID.ACTION_UNITS_ANTIJITTER);
require("bnb_js/timers")


const am = bnb.scene.getAssetManager();
const hair_module = require("./modules/hair/index.js")
const body_module = require("./modules/body/index.js")
const foreground_module = require("./modules/foreground/index.js")
const background_module = require("./modules/background/index.js")
const lut_module = require("./modules/lut/index.js")
const lights_module = require("./modules/lights/index.js")
const nose_module = require("./modules/nose/index.js")
const eyes_module = require("./modules/eyes/index.js")
const brows_module = require("./modules/brows/index.js")
const transform_module = require("./modules/transformation/index.js")
const outfit_module = require("./modules/outfit/index.js")
const glasses_module = require("./modules/glasses/index.js")


// speed from 0.0 to 1.0, less - slower, more - faster
const speedReturn = 0.25;
const speedDefault = 0.125;

const AvatarRegions = {
    "Face": new body_module.Face,
    "NoseShape": new nose_module.NoseShape,
    "EyesShape": new eyes_module.EyesShape,
    "Brows": new brows_module.Brows,
    "Hair": new hair_module.Hair,
    "Foreground": new foreground_module.Foreground,
    "Background": new background_module.Background,
    "Lut": new lut_module.Lut,
    "Lights": new lights_module.Lights,
    "Transformation": new transform_module.Transformation,
    "Glasses": new glasses_module.Glasses,
    "Outfit": new outfit_module.Outfit
}

function clear(){
    for (const region of Object.values(AvatarRegions)) region.clear()
}



function setState(state){
    clear()
    if(state)
        for (const [region, settings] of Object.entries(state)) AvatarRegions[region].parameters(settings)
}

let isScreenshot = false

function screenshot(check){
    if(check){
        AvatarRegions["Background"].clear();
        am.findMaterial("unused").findParameter("is_face_anim").setVector4(new bnb.Vec4(1., 1., 0., 0.));
        isScreenshot = true;
    } else {
        isScreenshot = false;
    }
}


const rot = am.findMaterial("unused").findParameter("face_rotation");
const face = bnb.scene.getRoot().findChildByName("face_tracker0").getComponent(bnb.ComponentType.FACE_TRACKER).asFaceTracker()

let anim = 0;
bnb.eventListener.on("onUpdate", function (args) {
    const transl = bnb.scene.getRoot().findChildByName("face_tracker0").getComponent(bnb.ComponentType.TRANSFORMATION).asTransformation().getTranslation()
        // bnb.log(anim)
        if(!isScreenshot){
            if (face.hasFace()) {
                    anim -= speedReturn;
                    anim = anim >= 0 ? anim : 0;

                rot.setVector4(new bnb.Vec4(transl.x, transl.y, transl.z, 0.))
                am.findMaterial("unused").findParameter("is_face_anim").setVector4(new bnb.Vec4(1., anim, 0., 0.));
            } else {
                rot.setVector4(new bnb.Vec4(transl.x, transl.y, transl.z, 0.))
                anim += speedDefault;
                anim = anim <= 1 ? anim : 1;
                // bnb.log(anim)
                am.findMaterial("unused").findParameter("is_face_anim").setVector4(new bnb.Vec4(0., anim, 0., 0.));
            }
        }
})

setState({
    "Face":{
        "shape":{
            "round": 0.0,
            "square": 0.8,
            "triangle": 0.0,
            "diamond": 0.0,
            "heart": 0.4,
            "pear": 0.0,
            "rectangular": 0.6,
            "oblong": 0.0,
            "ShapeMouthSizeVertical": 0.0,
            "ShapeMouthSizeHorizontal": 0.0,
            "ShapeMouthPositionVertical": 0.0
        },
        "makeups": {
            "wrinkles": {
                "type": "none",
                "color": "none"
            },
            "freckles":  {
                "type": "freckles_3",
                "color": "@1.0, 0., 0., 3."
            },
            "moles":  {
                "type": "none",
                "color": "none"
            },
            "blush":  {
                "type": "none",
                "color": "none"
            },
            "shadows":  {
                "type": "none",
                "color": "none"
            },
        }, 
        "lips":{
            "color": "0.44, 0.18, 0.18, 0.8",
            "metallic": 0.05,
            "roughness": 0.35
        },
        "color": "latino", 
        "gender": "male"
    },
    "NoseShape":{
        "length": 0.0,
        "width": 0.5,
        "height": 0.3
    },
    "EyesShape": {
        "ShapeEyeSizeVertical": 0.15,
        "ShapeEyeSizeHorizontal": 0.15,
        "ShapeEyeRoll": 0.0,
        "ShapeEyePositionVertical": 0.0,
        "ShapeEyePositionHorizontal": 0.4
    },
    "Brows":{
        "shape":{
            "thick": 0.9,
            "classic": 0.0,
            "angular": 0.0,
            "rounded": 0.0,
            "ShapeBrowSizeHorizontal": 0.0,
            "ShapeBrowPositionVertical": 0.0
        },
        "color": "@0.18, 0.15, 0.14"
    },
    "Hair":{
        "color": "@0.18, 0.11, 0.11", 
        "shape": "seventh" 
    },
    "Glasses":{
        "shape": "null" 
    },
    "Outfit":{
        "set": "fifth"
    },
    "Lights":{
        "radiance":[
            "0.37, 0.70, 0.59, 0.3",
            "0.47, 0.54, 0.34, 0.3",
            "0.31, 0.59, 0.70, 0.8",
            "0.96, 0.86, 0.63, 1.5"
        ],
        "lights":[
            "110.0, 70.0, -160.0",
            "-110.0, 20.0, -180.0",
            "0.0, 200.0, -50.0",
            "0.0, 60.0, 300.0"
        ]
    },
    "Lut": {
        "texture": "images/lut_beach.png",
        "strength": 1.0
    },
    "Transformation":{
        "position": "0.0, -80.0",
        "scale": 0.75
    },
    "Background":{
        "texture": "images/BG_beach.jpg",
        "aspect": "fill",
        "rotation": 0.0
    },
    "Foreground":{
        "texture": "images/FG_beach.png",
        "blending": "alpha", 
        "aspect": "fill",
        "rotation": 0.0
    }
})

