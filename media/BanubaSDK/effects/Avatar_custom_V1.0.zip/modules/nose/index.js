const am = bnb.scene.getAssetManager();

class NoseShape{
    shapes = {
        "length": 0.0,
        "width": 0.0,
        "height": 0.0,
    }
    lws = am.findMaterial("unused").findParameter("nose_shape_lws");
    
    parameters({length, width, height}){
        this.lws.setVector4(new bnb.Vec4(
            length ? length : 0.0, 
            width ? width : 0.0, 
            height ? height : 0.0, 
            0.0))
    }
    
    clear(){
        this.parameters(this.shapes)
    }
}

exports.NoseShape = NoseShape