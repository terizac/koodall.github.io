const am = bnb.scene.getAssetManager();

class Brows{
    settings = {
        "shape":{
            "thick": 0.0,
            "classic": 0.0,
            "angular": 0.0,
            "rounded": 0.0,
            "ShapeBrowSizeHorizontal": 0.0,
            "ShapeBrowPositionVertical": 0.0
        },
        "color": "default"
    }

    colors = {
        "default": "0.310, 0.176, 0.173",
        "color_1": "0.463, 0.427, 0.431",
        "color_2": "0.694, 0.670, 0.663",
        "color_3": "0.913, 0.859, 0.816",
        "color_4": "0.98, 0.953, 0.89",
        "color_5": "0.941, 0.847, 0.603",
        "color_6": "0.792, 0.647, 0.522",
        "color_7": "0.431, 0.318, 0.255",
        "color_8": "0.396, 0.188, 0.165",
    }
    tcar = am.findMaterial("unused").findParameter("brows_shape_tcar");
    sh_pv = am.findMaterial("unused").findParameter("brows_shape_sh_pv");

    brows_color = am.findMaterial("unused").findParameter("brows_color");

    setShape({thick, classic, angular, rounded, ShapeBrowSizeHorizontal, ShapeBrowPositionVertical}){
        this.tcar.setVector4(new bnb.Vec4(
            thick ? thick : 0.0, 
            classic ? classic : 0.0, 
            angular ? angular : 0.0, 
            rounded ? rounded : 0.0))
        this.sh_pv.setVector4(new bnb.Vec4(
            ShapeBrowSizeHorizontal ? ShapeBrowSizeHorizontal : 0.0, 
            ShapeBrowPositionVertical ? ShapeBrowPositionVertical : 0.0, 
            0.0, 
            0.0))
    }
    
    parameters({shape, color}){
        this.setShape(shape);
        let c;
        if(color.charAt(0) == "@"){
            c = color.substring(1);
        } else {
            c = this.colors[color] || this.colors["default"];
        }
        const [x,y,z] = c.split(',');
        this.brows_color.setVector4(new bnb.Vec4(x,y,z,1.0))
    }

    clear(){
        this.parameters(this.settings)
    }
}

exports.Brows = Brows