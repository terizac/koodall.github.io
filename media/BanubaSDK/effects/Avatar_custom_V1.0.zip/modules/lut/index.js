const am = bnb.scene.getAssetManager();

class Lut{
    constructor(){
        this.settings = {
            "texture": "images/null_lut.png",
            "strength": 0.0,
        }
        this.lut_strength = am.findMaterial("unused").findParameter("lut_strength");
        this.lut = bnb.scene.getRoot().findChildByName("Lut").getComponent(bnb.ComponentType.MESH_INSTANCE).asMeshInstance()
        this.texture = am.findImage("lut_image").asWeightedLut();
        this.parameters(this.settings)
        this.lut.setVisible(false);
    }

    parameters({texture, strength}){
        if(texture != undefined){
            this.texture.load(texture)
            this.lut.setVisible(true)
        }
        
        this.lut_strength.setVector4(new bnb.Vec4(strength,0., 0., 0.));
    }

    clear(){
        this.parameters(this.settings)
        this.lut.setVisible(false);
    }
}

exports.Lut = Lut;