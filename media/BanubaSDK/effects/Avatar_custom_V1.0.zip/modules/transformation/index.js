const am = bnb.scene.getAssetManager();

class Transformation {

    settings ={
        "position": "0., -130.",
        "scale": 0.89
    }
    position_scale = am.findMaterial("unused").findParameter("position_scale");
    position = bnb.scene.getRoot().findChildByName("Body").getComponent(bnb.ComponentType.TRANSFORMATION).asTransformation()
    sc = this.position.getScale();

    parameters({position, scale}){
        const [x,y] = position.split(',')
        this.position_scale.setVector4(new bnb.Vec4(x,y,0.0,scale))
        this.position.setScale(new bnb.Vec3(this.sc.x*scale,this.sc.y*scale,this.sc.z*scale))
    }

    clear(){
        this.parameters(this.settings)
    }
}

exports.Transformation = Transformation