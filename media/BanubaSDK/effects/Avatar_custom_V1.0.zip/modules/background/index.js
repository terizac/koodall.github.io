const am = bnb.scene.getAssetManager();

class Background{
    constructor(){
        this.settings = {
            "texture": "images/null_image.png",
            "aspect": "fill",
            "rotation": 0.0
        }
        this.background_aspect = am.findMaterial("unused").findParameter("background_aspect_rotation");
        this.background = bnb.scene.getRoot().findChildByName("Background").getComponent(bnb.ComponentType.MESH_INSTANCE).asMeshInstance()
        this.texture = am.findImage("background").asTexture();
        this.parameters(this.settings)
        this.background.setVisible(false);
    }

    parameters({texture, aspect, rotation}){
        let an = 1.;

        if(texture != undefined){
            this.texture.load(texture)
            this.background.setVisible(true)
        }
        if(aspect != undefined){
            const a = aspect.toLowerCase();

            switch(a){
                case "scale_to_fit":
                    an = 0.0;
                    break;
                case "fill":
                    an = 1.0;
                    break;
                case "fit":
                    an = 2.0;
                    break;
                default:
                    an = 1.0;
                    break;
            }
        }
        this.background_aspect.setVector4(new bnb.Vec4(an,rotation ? rotation : 0.0, 0., 0.))
    }

    clear(){
        this.parameters(this.settings)
        this.background.setVisible(false);
    }
}

exports.Background = Background;