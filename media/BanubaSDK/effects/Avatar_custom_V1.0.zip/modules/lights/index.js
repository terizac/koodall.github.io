const am = bnb.scene.getAssetManager();

class Lights{
    constructor(){
        this.radiance = [
            am.findMaterial("unused").findParameter("radiance_1"),
            am.findMaterial("unused").findParameter("radiance_2"),
            am.findMaterial("unused").findParameter("radiance_3"),
            am.findMaterial("unused").findParameter("radiance_4"),
            am.findMaterial("unused").findParameter("radiance_5"),
            am.findMaterial("unused").findParameter("radiance_6"),
            am.findMaterial("unused").findParameter("radiance_7"),
            am.findMaterial("unused").findParameter("radiance_8"),
            am.findMaterial("unused").findParameter("radiance_9"),
            am.findMaterial("unused").findParameter("radiance_10"),
        ]

        this.lights = [
            am.findMaterial("unused").findParameter("lights_1"),
            am.findMaterial("unused").findParameter("lights_2"),
            am.findMaterial("unused").findParameter("lights_3"),
            am.findMaterial("unused").findParameter("lights_4"),
            am.findMaterial("unused").findParameter("lights_5"),
            am.findMaterial("unused").findParameter("lights_6"),
            am.findMaterial("unused").findParameter("lights_7"),
            am.findMaterial("unused").findParameter("lights_8"),
            am.findMaterial("unused").findParameter("lights_9"),
            am.findMaterial("unused").findParameter("lights_10"),
        ]

        
    }

    parameters({radiance, lights}){
        for(let i = 0; i < this.radiance.length; i++){
            if(radiance[i] != undefined){
                const [x,y,z,w] = radiance[i].split(',');
                this.radiance[i].setVector4(new bnb.Vec4(x*w,y*w,z*w,0.0));
            } else{
                this.radiance[i].setVector4(new bnb.Vec4(0,0,0,0));
            }
            if(lights[i] != undefined){
                const [x,y,z] = lights[i].split(',');
                this.lights[i].setVector4(new bnb.Vec4(x,y,z,0.0));
            } else{
                this.lights[i].setVector4(new bnb.Vec4(0,0,0,0));
            }
        }
    }

    clear(){
        for(let i = 0; i < this.radiance.length; i++){
            this.radiance[i].setVector4(new bnb.Vec4(0,0,0,0));
            this.lights[i].setVector4(new bnb.Vec4(0,0,0,0));
        }
    }
}

exports.Lights = Lights;