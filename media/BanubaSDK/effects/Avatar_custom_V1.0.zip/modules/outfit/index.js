const am = bnb.scene.getAssetManager();

class Outfit{
    constructor(){
        this.settings = {
            "set": "first",
        }
        this.sets = {
            "null": [{ setActive: (visible) => { /* no operation */ } }],
            "first" : [bnb.scene.getRoot().findChildByName("Cloth_01"),],
            "second" : [bnb.scene.getRoot().findChildByName("Cloth_02"),],
            "third" : [bnb.scene.getRoot().findChildByName("Cloth_03"),],
            "fourth" : [bnb.scene.getRoot().findChildByName("Cloth_04"),],
            "fifth" : [bnb.scene.getRoot().findChildByName("Cloth_05"),],
            "sixth" : [bnb.scene.getRoot().findChildByName("Cloth_06"),],
            "seventh" : [bnb.scene.getRoot().findChildByName("Cloth_07"),],
            "eighth" : [bnb.scene.getRoot().findChildByName("Cloth_08"),],
            "ninth" : [bnb.scene.getRoot().findChildByName("Cloth_09"),],
            "tenth" : [bnb.scene.getRoot().findChildByName("Cloth_10"),],
            "eleventh" : [bnb.scene.getRoot().findChildByName("Cloth_11"),],
            "twelfth" : [bnb.scene.getRoot().findChildByName("Cloth_12"),],
            "thirteenth" : [bnb.scene.getRoot().findChildByName("Cloth_13"),],
            "fourteenth" : [bnb.scene.getRoot().findChildByName("Cloth_14"),]
        }

        for(const [set] of Object.entries(this.sets)) this.disable(set)
    }

    disable(set){
        this.sets[set].forEach(element => {
            element.setActive(false);
        });
    }

    enable(set){
        this.sets[set].forEach(element => {
            element.setActive(true);
        }); 
    }

    disableAll(){
        for(const [set] of Object.entries(this.sets)) this.disable(set)
    }

    parameters({set}){
        set && this.enable(set)
    }

    clear(){
        this.disableAll()
    }
}

exports.Outfit = Outfit