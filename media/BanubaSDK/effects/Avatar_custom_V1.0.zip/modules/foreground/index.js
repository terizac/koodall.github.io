const am = bnb.scene.getAssetManager();

class Foreground{
    constructor(){
        this.settings = {
            "texture": "images/null_image.png",
            "mode": "alpha",
            "aspect": "fill",
            "rotation": 0.0
        }
        this.foreground_mode_aspect = am.findMaterial("unused").findParameter("foreground_mode_aspect_rotation");
        this.foreground = bnb.scene.getRoot().findChildByName("Foreground").getComponent(bnb.ComponentType.MESH_INSTANCE).asMeshInstance()
        this.texture = am.findImage("foreground").asTexture();
        this.parameters(this.settings)
        this.foreground.setVisible(false);
    }

    parameters({texture, blending, aspect, rotation}){

        let mn = 9.;
        let an = 1.;

        if(texture != undefined){
            this.texture.load(texture)
            this.foreground.setVisible(true)
        }
        if(aspect != undefined){
            const a = aspect.toLowerCase();

            switch(a){
                case "scale_to_fit":
                    an = 0.0;
                    break;
                case "fill":
                    an = 1.0;
                    break;
                case "fit":
                    an = 2.0;
                    break;
                default:
                    an = 1.0;
                    break;
            }
        }
        if(blending != undefined){
            const m = blending.toLowerCase();
            switch(m){
                case "normal":
                    mn = 0.0;
                    break;
                case "multiply":
                    mn = 1.0;
                    break;
                case "screen":
                    mn = 2.0;
                    break;
                case "overlay":
                    mn = 3.0;
                    break;
                case "softlight":
                    mn = 4.0;
                    break;
                case "hardlight":
                    mn = 5.0;
                    break;
                case "add":
                    mn = 6.0;
                    break;
                case "lighten":
                    mn = 7.0;
                    break;
                case "colordodge":
                    mn = 8.0;
                    break;
                case "alpha":
                    mn = 9.0;
                    break;
            }
        }

        this.foreground_mode_aspect.setVector4(new bnb.Vec4(mn,an, rotation ? rotation : 0.0, 0.))
    }

    clear(){
        this.parameters(this.settings)
        this.foreground.setVisible(false);
    }
}

exports.Foreground = Foreground;