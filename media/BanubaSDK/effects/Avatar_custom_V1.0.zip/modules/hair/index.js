const am = bnb.scene.getAssetManager();

class Hair{
    constructor(){
        this.settings = {
            "shape": "first",
        }

        this.colors = {
            "default": "0.310, 0.176, 0.173",
            "color_1": "0.463, 0.427, 0.431",
            "color_2": "0.694, 0.670, 0.663",
            "color_3": "0.913, 0.859, 0.816",
            "color_4": "0.98, 0.953, 0.89",
            "color_5": "0.941, 0.847, 0.603",
            "color_6": "0.792, 0.647, 0.522",
            "color_7": "0.431, 0.318, 0.255",
            "color_8": "0.396, 0.188, 0.165",
        }

        this.shapes = {
            "null" : {setVisible: (visible) => { /* no operation */ }},
            "first" : bnb.scene.getRoot().findChildByName("Hair_01").getComponent(bnb.ComponentType.MESH_INSTANCE).asMeshInstance(),
            "second" : bnb.scene.getRoot().findChildByName("Hair_02").getComponent(bnb.ComponentType.MESH_INSTANCE).asMeshInstance(),
            "third" : bnb.scene.getRoot().findChildByName("Hair_03").getComponent(bnb.ComponentType.MESH_INSTANCE).asMeshInstance(),
            "fourth" : bnb.scene.getRoot().findChildByName("Hair_04").getComponent(bnb.ComponentType.MESH_INSTANCE).asMeshInstance(),
            "fifth" : bnb.scene.getRoot().findChildByName("Hair_05").getComponent(bnb.ComponentType.MESH_INSTANCE).asMeshInstance(),
            "sixth" : bnb.scene.getRoot().findChildByName("Hair_06").getComponent(bnb.ComponentType.MESH_INSTANCE).asMeshInstance(),
            "seventh" : bnb.scene.getRoot().findChildByName("Hair_07").getComponent(bnb.ComponentType.MESH_INSTANCE).asMeshInstance(),
            "eighth" : bnb.scene.getRoot().findChildByName("Hair_08").getComponent(bnb.ComponentType.MESH_INSTANCE).asMeshInstance(),
            "ninth" : bnb.scene.getRoot().findChildByName("Hair_09").getComponent(bnb.ComponentType.MESH_INSTANCE).asMeshInstance(),
            "tenth" : bnb.scene.getRoot().findChildByName("Hair_10").getComponent(bnb.ComponentType.MESH_INSTANCE).asMeshInstance(),
            "eleventh" : bnb.scene.getRoot().findChildByName("Hair_11").getComponent(bnb.ComponentType.MESH_INSTANCE).asMeshInstance(),
            "twelfth" : bnb.scene.getRoot().findChildByName("Hair_12").getComponent(bnb.ComponentType.MESH_INSTANCE).asMeshInstance(),
            "thirteenth" : bnb.scene.getRoot().findChildByName("Hair_13").getComponent(bnb.ComponentType.MESH_INSTANCE).asMeshInstance()
        }
        this.hair_color = am.findMaterial("unused").findParameter("hair_color");

        for(const [name, shape] of Object.entries(this.shapes)) this.disable(shape)
    }

    disable(shape){
        shape.setVisible(false);
    }

    disableAll(){
        for(const [name, shape] of Object.entries(this.shapes)) this.disable(shape)
    }

    parameters({color, shape}){
        let c;
        if(color.charAt(0) == "@"){
            c = color.substring(1);
        } else {
            c = this.colors[color] || this.colors["default"];
        }
        const [x,y,z] = c.split(',');
        this.hair_color.setVector4(new bnb.Vec4(x,y,z,1.0))
        shape && this.shapes[shape].setVisible(true)
    }

    clear(){
        this.parameters({color: "default"})
        this.disableAll()
    }
}

exports.Hair = Hair