const am = bnb.scene.getAssetManager();

class Face {
    settings = {
        "shape":{
            "round": 0.0,
            "square": 0.0,
            "triangle": 0.0,
            "diamond": 0.0,
            "heart": 0.0,
            "pear": 0.0,
            "rectangular": 0.0,
            "oblong": 0.0,
            "ShapeMouthSizeVertical": 0.0,
            "ShapeMouthSizeHorizontal": 0.0,
            "ShapeMouthPositionVertical": 0.0
        },
        "makeups": {
            "wrinkles": {
                "type": "none",
                "color": "none"
            },
            "freckles":  {
                "type": "none",
                "color": "none"
            },
            "moles":  {
                "type": "none",
                "color": "none"
            },
            "blush":  {
                "type": "none",
                "color": "none"
            },
            "shadows":  {
                "type": "none",
                "color": "none"
            },
        },
        "color": "white",
        "gender": "male",
        "lips":{
            "color": "0.0, 0.0, 0.0, 0.0",
            "metallic": 1.0,
            "roughness": 1.0
        } 
    }

    colors = {
        "white": "0.93, 0.80, 0.70",
        "afro": "0.47, 0.35, 0.27",
        "asian": "0.795, 0.65, 0.51",
        "indian": "0.70, 0.51, 0.37",
        "latino": "0.76, 0.59, 0.46",
        "color_1": "0.996, 0.976, 0.964",
        "color_2": "0.992, 0.956, 0.941",
        "color_3": "0.988, 0.925, 0.89",
        "color_4": "0.984, 0.909, 0.87",
        "color_5": "0.98, 0.89, 0.847",
        "color_6": "0.976, 0.855, 0.8",
        "color_7": "0.964, 0.905, 0.839",
        "color_8": "0.941, 0.874, 0.788",
        "color_9": "0.933, 0.855, 0.741",
        "color_10": "0.909, 0.815, 0.709",
        "color_11": "0.913, 0.792, 0.635",
        "color_12": "0.863, 0.733, 0.561",
        "color_13": "0.894, 0.769, 0.627",
        "color_14": "0.89, 0.729, 0.545",
        "color_15": "0.827, 0.631, 0.451",
        "color_16": "0.702, 0.49, 0.314",
        "color_17": "0.596, 0.384, 0.219",
        "color_18": "0.427, 0.247, 0.141",
        "color_19": "0.819, 0.722, 0.667",
        "color_20": "0.757, 0.667, 0.624",
        "color_21": "0.635, 0.533, 0.506",
        "color_22": "0.506, 0.419, 0.412",
        "color_23": "0.392, 0.314, 0.302",
        "color_24": "0.259, 0.2, 0.192",
        "color_25": "0.49, 0.329, 0.231",
        "color_26": "0.475, 0.314, 0.216",
        "color_27": "0.373, 0.235, 0.145",
        "color_28": "0.357, 0.219, 0.129",
        "color_29": "0.235, 0.137, 0.078",
        "color_30": "0.207, 0.109, 0.059",
    }

    images = {
        "male": {
            "base": "modules/body/male_head_BaseColor.jpg",
            "overlay": "modules/body/male_head_overlay.jpg"
        },
        "female": {
            "base": "modules/body/female_head_BaseColor.jpg",
            "overlay": "modules/body/female_head_overlay.jpg"
        },
        "makeup":{
            "wrinkles":{
                "none": "images/null_alpha.jpg",
                "wrinkles_1": "images/wrinkles/mat_wrinkles_01_alpha.jpg",
                "wrinkles_2": "images/wrinkles/mat_wrinkles_02_alpha.jpg",
                "wrinkles_3": "images/wrinkles/mat_wrinkles_03_alpha.jpg"
            },
            "freckles":{
                "none": "images/null_alpha.jpg",
                "freckles_1": "images/freckles/mat_freckles_01_alpha.jpg",
                "freckles_2": "images/freckles/mat_freckles_02_alpha.jpg",
                "freckles_3": "images/freckles/mat_freckles_03_alpha.jpg",
            },
            "moles":{
                "none": "images/null_alpha.jpg"
            },
            "blush":{
                "none": "images/null_alpha.jpg"
            },
            "shadows":{
                "none": "images/null_alpha.jpg"
            }
        }
    }

    makeup_colors = {
        "none": "0., 0., 0., 0."
    }

    rstd = am.findMaterial("unused").findParameter("face_shape_rstd");
    hpro = am.findMaterial("unused").findParameter("face_shape_hpro");
    mouth_shape_sv_sh_pv = am.findMaterial("unused").findParameter("mouth_shape_sv_sh_pv");
    face_color = am.findMaterial("unused").findParameter("face_color");
    lips_color = am.findMaterial("unused").findParameter("lips_color");
    lips_mr = am.findMaterial("unused").findParameter("lips_mr");
    wrinkles_color = am.findMaterial("unused").findParameter("wrinkles_color");
    freckles_color = am.findMaterial("unused").findParameter("freckles_color");
    moles_color = am.findMaterial("unused").findParameter("moles_color");
    blush_color = am.findMaterial("unused").findParameter("blush_color");
    shadows_color = am.findMaterial("unused").findParameter("shadows_color");

    gender = am.findMaterial("unused").findParameter("face_gender");

    base_texture = am.findImage("base").asTexture();
    overlay_texture = am.findImage("overlay").asTexture();
    wrinkles = am.findImage("wrinkles").asTexture();
    freckles = am.findImage("freckles").asTexture();
    moles = am.findImage("moles").asTexture();
    blush = am.findImage("blush").asTexture();
    shadows = am.findImage("shadows").asTexture();

    setShape({round, square, triangle, diamond, heart, pear, rectangular, oblong, ShapeMouthSizeVertical, ShapeMouthSizeHorizontal, ShapeMouthPositionVertical}){
        this.rstd.setVector4(new bnb.Vec4(
            round ? round : 0.0, 
            square ? square : 0.0, 
            triangle ? triangle : 0.0, 
            diamond ? diamond : 0.0))

        this.hpro.setVector4(new bnb.Vec4(
            heart ? heart : 0.0, 
            pear ? pear : 0.0, 
            rectangular ? rectangular : 0.0,
            oblong ? oblong : 0.0))

        this.mouth_shape_sv_sh_pv.setVector4(new bnb.Vec4(
            ShapeMouthSizeVertical ? ShapeMouthSizeVertical : 0.0, 
            ShapeMouthSizeHorizontal ? ShapeMouthSizeHorizontal : 0.0, 
            ShapeMouthPositionVertical ? ShapeMouthPositionVertical : 0.0,
            0.0))
    }

    setColor(color){
        let c;
        if(color.charAt(0) == "@"){
            c = color.substring(1);
        } else {
            c = this.colors[color] || this.colors["white"];
        }
        const [x,y,z] = c.split(',')
        this.face_color.setVector4(new bnb.Vec4(x,y,z,0.));
    }

    setMakeups({wrinkles,freckles,moles,blush,shadows}){
        wrinkles && this.setWrinkles(wrinkles)
        freckles && this.setFreckles(freckles)
        moles && this.setMoles(moles)
        blush && this.setBlush(blush)
        shadows && this.setShadows(shadows)
    }

    setWrinkles(params){
        if(params){
            if(params.type){
                if(params.type.charAt(0) == "@"){
                    let path = params.type.substring(1);
                    this.wrinkles.load(path)
                }else{
                    this.wrinkles.load(this.images.makeup.wrinkles[params.type])
    
                }
            }
            if(params.color){
                let c;
                if(params.color.charAt(0) == "@"){
                    c = params.color.substring(1);
                } else {
                    c = this.makeup_colors[params.color] || this.makeup_colors["none"];
                }
                const [x,y,z, w] = c.split(',')
                this.wrinkles_color.setVector4(new bnb.Vec4(x,y,z,w));
            }
        }
    }

    setShadows(params){
        if(params){
            if(params.type){
                if(params.type.charAt(0) == "@"){
                    let path = params.type.substring(1);
                    this.shadows.load(path)
                }else{
                    this.shadows.load(this.images.makeup.shadows[params.type])
                }
            }
            if(params.color){
                let c;
                if(params.color.charAt(0) == "@"){
                    c = params.color.substring(1);
                } else {
                    c = this.makeup_colors[params.color] || this.makeup_colors["none"];
                }
                const [x,y,z, w] = c.split(',')
                this.shadows_color.setVector4(new bnb.Vec4(x,y,z,w));
            }
        }
    }

    setBlush(params){
        if(params){
            if(params.type){
                if(params.type.charAt(0) == "@"){
                    let path = params.type.substring(1);
                    this.blush.load(path)
                }else{
                    this.blush.load(this.images.makeup.blush[params.type])
                }
            }
            if(params.color){
                let c;
                if(params.color.charAt(0) == "@"){
                    c = params.color.substring(1);
                } else {
                    c = this.makeup_colors[params.color] || this.makeup_colors["none"];
                }
                const [x,y,z, w] = c.split(',')
                this.blush_color.setVector4(new bnb.Vec4(x,y,z,w));
            }
        }
    }

    setMoles(params){
        if(params){
            if(params.type){
                if(params.type.charAt(0) == "@"){
                    let path = params.type.substring(1);
                    this.moles.load(path)
                }else{
                    this.moles.load(this.images.makeup.moles[params.type])
                }
            }
            if(params.color){
                let c;
                if(params.color.charAt(0) == "@"){
                    c = params.color.substring(1);
                } else {
                    c = this.makeup_colors[params.color] || this.makeup_colors["none"];
                }
                const [x,y,z, w] = c.split(',')
                this.moles_color.setVector4(new bnb.Vec4(x,y,z,w));
            }
        }
    }

    setFreckles(params){
        if(params){
            if(params.type.charAt(0) == "@"){
                let path = params.type.substring(1);
                this.freckles.load(path)
            }else{
                this.freckles.load(this.images.makeup.freckles[params.type])

            }
            let c;
            if(params.color.charAt(0) == "@"){
                c = params.color.substring(1);
            } else {
                c = this.makeup_colors[params.color] || this.makeup_colors["none"];
            }
            const [x,y,z, w] = c.split(',')
            this.freckles_color.setVector4(new bnb.Vec4(x,y,z,w));
        }
    }

    setGender(gender){
        if(gender){
            switch(gender){
                case "male":
                    this.base_texture.load(this.images.male.base)
                    this.overlay_texture.load(this.images.male.overlay)
                    this.gender.setVector4(new bnb.Vec4(0.))
                    break;
                case "female":
                    this.base_texture.load(this.images.female.base)
                    this.overlay_texture.load(this.images.female.overlay)
                    this.gender.setVector4(new bnb.Vec4(1.))
                    break;
            }
        }
    }

    setLips({color,metallic,roughness}){
        const [x,y,z,w] = color.split(',')
        this.lips_color.setVector4(new bnb.Vec4(x,y,z,w));
        this.lips_mr.setVector4(new bnb.Vec4(metallic, roughness, 0., 0.));
    }

    parameters({shape, makeups, color, gender, lips}){
        makeups && this.setMakeups(makeups);
        shape && this.setShape(shape);
        color && this.setColor(color);
        gender && this.setGender(gender)
        lips && this.setLips(lips)
    }

    clear(){
        this.parameters(this.settings)
    }
}

exports.Face = Face;