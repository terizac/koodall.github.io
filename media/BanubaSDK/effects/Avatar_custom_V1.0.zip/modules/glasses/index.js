const am = bnb.scene.getAssetManager();

class Glasses{
    constructor(){
        this.settings = {
            "shape": "first",
        }
        this.shapes = {
            "null" : {setVisible: (visible) => { /* no operation */ }},
            "first" : bnb.scene.getRoot().findChildByName("Glasses").getComponent(bnb.ComponentType.MESH_INSTANCE).asMeshInstance(),
        }

        for(const [shape] of Object.entries(this.shapes)) this.disable(shape)
    }

    disable(shape){
        shape && this.shapes[shape].setVisible(false)
    }

    disableAll(){
        for(const [shape] of Object.entries(this.shapes)) this.disable(shape)
    }

    parameters({shape}){
        shape && this.shapes[shape].setVisible(true)
    }

    clear(){
        this.disableAll()
    }
}

exports.Glasses = Glasses