const am = bnb.scene.getAssetManager();

class EyesShape{
    shapes = {
        "ShapeEyeSizeVertical": 0.0,
        "ShapeEyeSizeHorizontal": 0.0,
        "ShapeEyeRoll": 0.0,
        "ShapeEyePositionVertical": 0.0,
        "ShapeEyePositionHorizontal": 0.0,
    }
    rdum = am.findMaterial("unused").findParameter("eyes_shape_rdum");
    ws = am.findMaterial("unused").findParameter("eyes_shape_ws");

    
    parameters({ShapeEyeSizeVertical, ShapeEyeSizeHorizontal, ShapeEyeRoll, ShapeEyePositionVertical, ShapeEyePositionHorizontal}){
        this.rdum.setVector4(new bnb.Vec4(
            ShapeEyeSizeVertical ? ShapeEyeSizeVertical : 0.0, 
            ShapeEyeSizeHorizontal ? ShapeEyeSizeHorizontal : 0.0, 
            ShapeEyeRoll ? ShapeEyeRoll : 0.0, 
            ShapeEyePositionVertical ? ShapeEyePositionVertical : 0.0))
        this.ws.setVector4(new bnb.Vec4(
            ShapeEyePositionHorizontal ? ShapeEyePositionHorizontal : 0.0, 
            0.0, 
            0.0, 
            0.0))

    }

    clear(){
        this.parameters(this.shapes)
    }
}

exports.EyesShape = EyesShape