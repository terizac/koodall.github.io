const BgImpl = require('bnb_js/background');

class Background extends BgImpl.constructor
{
    constructor() {
        super()
    }
}

exports = {
    Background
}
