const teeth_tone = 'C4'

bnb.scene.enableRecognizerFeature(bnb.FeatureID.TEETH_TONE);

const vita_lab = {
    'BL1': [216,129,122], 
    'BL2': [203,129,123], 
    'BL3': [210,129,127], 
    'BL4': [204,128,130],
    'A1':  [204,127,135],
    'A2':  [193,128,140],
    'A3':  [193,128,141],
    'A35': [185,128,148],
    'A4':  [178,129,146],
    'B1':  [201,127,131],
    'B2':  [200,126,139],
    'B3':  [187,127,147],
    'B4':  [187,127,150],
    'C1':  [189,128,135],
    'C2':  [183,127,142],
    'C3':  [176,128,145],
    'C4':  [167,128,148],
    'D2':  [188,128,135],
    'D3':  [188,127,143],
    'D4':  [183,126,144]
}

let sellected_tone = vita_lab[teeth_tone]

const param = new bnb.FeatureParameter(sellected_tone[0], sellected_tone[1], sellected_tone[2], 0);
bnb.scene.addFeatureParam(bnb.FeatureID.TEETH_TONE, [param])